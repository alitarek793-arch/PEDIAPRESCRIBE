# PEDIAPRESCRIBE — projet Android (source, pas encore APK)

Ce dossier est un projet Android Studio minimal qui embarque la version web locale de PEDIAPRESCRIBE dans une WebView. Il permet de produire un APK après compilation.

## Générer l'APK avec Android Studio
1. Sur un ordinateur, installer Android Studio récent et le SDK Android 35.
2. Décompresser ce dossier.
3. Dans Android Studio : **Open** puis sélectionner le dossier `PEDIAPRESCRIBE_Android`.
4. Attendre la synchronisation Gradle.
5. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. L'APK de test sera normalement dans `app/build/outputs/apk/debug/app-debug.apk`.
7. Transférer cet APK sur le téléphone Android et l'installer. Android peut demander d'autoriser l'installation depuis cette source.

## Limites
- Ce livrable est le projet source Android, pas un fichier APK compilé ou signé.
- Le contenu médical embarqué est celui de la version initiale locale : les calculs sont arithmétiques et les posologies / présentations tunisiennes ne sont pas validées.
- Ne pas utiliser pour prescrire en situation réelle avant validation médicale, pharmacologique, réglementaire et cybersécurité.
- Les données sont stockées dans le stockage local WebView de l'application. Pas de synchronisation serveur ni de chiffrement applicatif spécifique.
